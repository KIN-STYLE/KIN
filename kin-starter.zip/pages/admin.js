
import { useEffect, useState } from "react";
import { auth } from "../lib/firebase";
import { onAuthStateChanged } from "firebase/auth";
import ProductForm from "../components/ProductForm";

export default function Admin() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser?.email === "TAVO_EMAIL@PASTAS.LT") {
        setUser(currentUser);
      }
    });
    return () => unsubscribe();
  }, []);

  if (!user) return <p>Prieiga tik administratoriui</p>;

  return (
    <div>
      <h1>Admin Valdymas</h1>
      <ProductForm />
    </div>
  );
}
