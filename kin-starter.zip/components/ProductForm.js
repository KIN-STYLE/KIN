
export default function ProductForm() {
  return (
    <form>
      <input placeholder="Pavadinimas" />
      <input placeholder="Kaina" />
      <button>Įkelti</button>
    </form>
  );
}
