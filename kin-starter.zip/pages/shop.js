
export default function Shop() {
  return <h1>Prekių katalogas (čia atsiras prekės)</h1>;
}
