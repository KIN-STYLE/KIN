
import { useState } from "react";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../lib/firebase";
import { useRouter } from "next/router";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const router = useRouter();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      await signInWithEmailAndPassword(auth, email, password);
      router.push("/admin");
    } catch (err) {
      setError("Nepavyko prisijungti");
    }
  };

  return (
    <form onSubmit={handleLogin}>
      <input type="email" placeholder="El. paštas" value={email} onChange={(e) => setEmail(e.target.value)} required />
      <input type="password" placeholder="Slaptažodis" value={password} onChange={(e) => setPassword(e.target.value)} required />
      <button type="submit">Prisijungti</button>
      {error && <p>{error}</p>}
    </form>
  );
}
